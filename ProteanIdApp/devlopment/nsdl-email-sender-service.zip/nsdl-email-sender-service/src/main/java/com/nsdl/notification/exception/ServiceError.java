package com.nsdl.notification.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ServiceError {

	private String errorCode;

	private String message;

	public ServiceError(String errorCode, String errorMessage) {
		this.errorCode = errorCode;
		this.message = errorMessage;
	}
}
