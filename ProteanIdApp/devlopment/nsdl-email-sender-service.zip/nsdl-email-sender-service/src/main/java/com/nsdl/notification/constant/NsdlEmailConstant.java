package com.nsdl.notification.constant;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class NsdlEmailConstant {
	
	public static final String NSDL_EMAIL_SENT_SUCCESS="Email sent successfully";


}
