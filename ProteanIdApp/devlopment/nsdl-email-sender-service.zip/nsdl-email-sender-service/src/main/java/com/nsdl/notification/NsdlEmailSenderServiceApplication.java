package com.nsdl.notification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NsdlEmailSenderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NsdlEmailSenderServiceApplication.class, args);
	}

}
