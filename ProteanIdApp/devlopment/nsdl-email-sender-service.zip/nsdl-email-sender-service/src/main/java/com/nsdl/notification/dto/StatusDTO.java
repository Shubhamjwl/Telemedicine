package com.nsdl.notification.dto;


import lombok.Data;


@Data
public class StatusDTO {
	
	private String message;
	private String status;
}
