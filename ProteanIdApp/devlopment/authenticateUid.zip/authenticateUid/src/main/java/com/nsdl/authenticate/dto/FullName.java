package com.nsdl.authenticate.dto;

import lombok.Data;

@Data
public class FullName {

	private String language;
	private String value;
}
