package com.nsdl.authenticate.dto;

import lombok.Data;

@Data
public class VerifyUidOtpResponse {
	
	private String uidVerificationStatus;
}
