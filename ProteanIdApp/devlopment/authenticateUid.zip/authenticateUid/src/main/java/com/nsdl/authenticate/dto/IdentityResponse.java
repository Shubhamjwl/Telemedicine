package com.nsdl.authenticate.dto;

import java.util.List;

import lombok.Data;
@Data
public class IdentityResponse {

	private List<FullName> fullName;

    public void setFullName(List<FullName> fullName){
        this.fullName = fullName;
    }
    public List<FullName> getFullName(){
        return this.fullName;
    }
}
