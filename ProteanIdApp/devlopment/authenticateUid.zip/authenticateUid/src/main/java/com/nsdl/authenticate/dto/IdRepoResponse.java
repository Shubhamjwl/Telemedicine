package com.nsdl.authenticate.dto;

import java.util.List;

import lombok.Data;

@Data
public class IdRepoResponse {
	
	/** The entity. */
	private String entity;
	
	/** The identity. */
	private Object identity;
	
	private List<Documents> documents;
	
	/** The status. */
	private String status;

}
