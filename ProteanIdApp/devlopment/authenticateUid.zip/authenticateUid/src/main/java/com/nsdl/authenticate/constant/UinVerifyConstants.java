package com.nsdl.authenticate.constant;

import lombok.Data;

@Data
public class UinVerifyConstants {
	
	public static final String UIN_VERIFICATION_SUCCESS="UID Verified Successfully and OTP Sent Successfully";
	public static final String EMAIL_CONTENT="Your UID authentication otp is ";


}
