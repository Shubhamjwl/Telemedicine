package com.nsdl.authenticate.dto;

import lombok.Data;

@Data
public class BioRequest {
	
	private String uid;

}
