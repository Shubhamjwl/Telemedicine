package com.nsdl.authenticate.dto;

import lombok.Data;

@Data
public class IndividualBiometrics {

	    private String format;
	    private Double version;
	    private String value;
}
