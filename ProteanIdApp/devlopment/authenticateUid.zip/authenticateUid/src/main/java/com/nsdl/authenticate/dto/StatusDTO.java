package com.nsdl.authenticate.dto;

import lombok.Data;

@Data
public class StatusDTO {
	

	public String message;
	public String status;
	
	public StatusDTO() {
		
	}

}
