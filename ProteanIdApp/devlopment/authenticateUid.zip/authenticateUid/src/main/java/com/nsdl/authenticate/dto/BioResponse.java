package com.nsdl.authenticate.dto;

import lombok.Data;

@Data
public class BioResponse {
	
	private byte[] photo;

}
