package com.nsdl.authenticate.dto;

import lombok.Data;

@Data
public class VerifyUidOtpRequest {
	
	private String uid;

}
