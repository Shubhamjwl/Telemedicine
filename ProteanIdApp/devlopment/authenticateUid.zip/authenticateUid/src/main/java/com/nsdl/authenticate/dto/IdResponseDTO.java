package com.nsdl.authenticate.dto;

public class IdResponseDTO extends ResponseWrapper<IdRepoResponse> {

}
