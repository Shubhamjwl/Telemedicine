package com.nsdl.authenticate;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticateUidApplicationTests {

	@Test
	void contextLoads() {
	}

}
